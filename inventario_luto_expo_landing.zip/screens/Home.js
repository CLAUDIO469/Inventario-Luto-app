import React from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Image source={require("../assets/splash.png")} style={styles.image} resizeMode="contain" />
      <Text style={styles.title}>Inventário de Luto Prolongado</Text>
      <Text style={styles.subtitle}>Promover consciência sobre possíveis dificuldades diante do luto e orientar para ajuda quando necessário.</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Questionnaire")}>
        <Text style={styles.buttonText}>Iniciar Avaliação</Text>
      </TouchableOpacity>
      <Text style={styles.small}>Aviso: este instrumento não substitui avaliação clínica. Se houver risco iminente, procure serviços de emergência.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, alignItems:"center", justifyContent:"center", padding:20, backgroundColor:"#F6F9FF" },
  image: { width:300, height:200, marginBottom:10 },
  title: { fontSize:22, fontWeight:"700", color:"#4A90E2", textAlign:"center", marginBottom:8 },
  subtitle: { textAlign:"center", color:"#555", marginBottom:16 },
  button: { backgroundColor:"#7B61FF", paddingHorizontal:20, paddingVertical:12, borderRadius:12 },
  buttonText: { color:"#fff", fontWeight:"700" },
  small: { marginTop:16, fontSize:12, color:"#777", textAlign:"center" }
});
