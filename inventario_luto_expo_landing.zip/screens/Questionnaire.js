import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, TextInput } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STANDARD_ITEMS = [
  "Estou com saudades do falecido.",
  "Estou preocupado com os pensamentos acerca do falecido ou circunstâncias da sua morte.",
  "Tenho sentimentos intensos de pesar em relação ao falecido.",
  "Sinto-me culpado pela morte ou pelas circunstâncias em que ocorreu.",
  "Estou revoltado com a perda.",
  "Tento evitar coisas que me lembrem do falecido ou a sua morte tanto quanto possível (p. ex., fotografias, memórias).",
  "Eu culpo outros ou as circunstâncias pela morte (p. ex., um poder divino).",
  "Eu tenho problemas em aceitar a morte ou simplesmente não quero fazê-lo.",
  "Sinto que perdi uma parte de mim próprio.",
  "Tenho problemas em sentir alegria e satisfação ou não tenho desejo de as sentir.",
  "Sinto-me emocionalmente adormecido.",
  "Tenho dificuldades em envolver-me em atividades de que gostava antes da perda.",
  "O luto interfere significativamente com a minha capacidade para trabalhar, socializar ou funcionar na minha vida do dia-a-dia.",
  "O meu luto pode ser considerado como pior (ex., mais intenso, grave e/ou longo) do que outros na minha comunidade ou cultura."
];

const STORAGE_KEY = "@ipgds_answers_v1";

export default function Questionnaire({ navigation }) {
  const [answers, setAnswers] = useState(Array(STANDARD_ITEMS.length).fill(null));
  const [name, setName] = useState("");
  const [timeSinceLoss, setTimeSinceLoss] = useState("");

  useEffect(()=>{ load(); }, []);

  async function load(){
    try{
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if(raw){
        const obj = JSON.parse(raw);
        setAnswers(obj.answers || Array(STANDARD_ITEMS.length).fill(null));
        setName(obj.name || "");
        setTimeSinceLoss(obj.timeSinceLoss || "");
      }
    }catch(e){ console.warn(e); }
  }

  function setAnswer(i, v){
    const arr = [...answers];
    arr[i] = v;
    setAnswers(arr);
  }

  function score(){
    const nums = answers.filter(n => typeof n === "number");
    const total = nums.reduce((s,v)=>s+v,0);
    return total;
  }

  async function saveAndShowResults(){
    const totalAnswered = answers.filter(n=>typeof n==="number").length;
    if(totalAnswered < 7){
      Alert.alert("Aviso", "Recomendamos responder pelo menos metade das questões para uma avaliação mais fiável.");
    }
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ answers, name, timeSinceLoss, savedAt: new Date().toISOString() }));
    navigation.navigate("Results", { total: score(), answered: totalAnswered });
  }

  return (
    <View style={{ flex:1, backgroundColor:"#FFFFFF" }}>
      <ScrollView contentContainerStyle={{ padding:16 }}>
        <Text style={{ fontSize:18, fontWeight:"700", color:"#4A90E2", marginBottom:8 }}>Questionário — Escala Standard</Text>
        <Text style={{ color:"#555", marginBottom:12 }}>Responda como se sentiu na última semana. Escala: 1 (Nada) — 5 (Extremamente)</Text>

        <TextInput placeholder="Nome (opcional)" value={name} onChangeText={setName} style={{ borderWidth:1, borderColor:"#EEE", padding:8, borderRadius:8, marginBottom:8 }} />
        <TextInput placeholder="Tempo desde a perda (ex: 6 meses, 2 anos)" value={timeSinceLoss} onChangeText={setTimeSinceLoss} style={{ borderWidth:1, borderColor:"#EEE", padding:8, borderRadius:8, marginBottom:12 }} />

        {STANDARD_ITEMS.map((it, i) => (
          <View key={i} style={styles.card}>
            <Text style={{ fontWeight:"600" }}>{i+1}. {it}</Text>
            <View style={{ flexDirection:"row", marginTop:8 }}>
              {[1,2,3,4,5].map(v=>(
                <TouchableOpacity key={v} style={[styles.choice, answers[i]===v?{ borderColor:"#7B61FF", backgroundColor:"#F3F0FF" }:null]} onPress={()=>setAnswer(i,v)}>
                  <Text style={{ fontWeight:"700"}}>{v}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        <View style={{ height:16 }} />

        <TouchableOpacity style={styles.primary} onPress={saveAndShowResults}>
          <Text style={{ color:"#fff", fontWeight:"700" }}>Ver Resultados</Text>
        </TouchableOpacity>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { padding:12, borderRadius:10, backgroundColor:"#FAFAFA", marginBottom:10, borderWidth:1, borderColor:"#EEE" },
  choice: { padding:12, marginRight:8, borderRadius:8, borderWidth:1, borderColor:"#DDD", width:48, alignItems:"center", justifyContent:"center" },
  primary: { backgroundColor:"#7B61FF", margin:16, padding:14, borderRadius:12, alignItems:"center", justifyContent:"center" }
});
