import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Alert } from "react-native";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import * as FileSystem from "expo-file-system";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "@ipgds_answers_v1";

export default function Results({ route, navigation }) {
  const { total, answered } = route.params || { total:0, answered:0 };
  const [data, setData] = useState(null);

  useEffect(()=>{ loadData(); }, []);

  async function loadData(){
    try{
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if(raw){
        setData(JSON.parse(raw));
      }
    }catch(e){ console.warn(e); }
  }

  // Cutoffs per user instruction:
  // <30 green, 30-34 yellow (attention), >=35 red (probable TLP stronger)
  let color = "#4CAF50";
  let label = "Verde — Sintomas baixos";
  let advice = "Sintomas dentro do esperado; continue a acompanhar. Procure ajuda se piorar.";
  if(total >= 30 && total < 35){
    color = "#FFA000";
    label = "Amarelo — Sintomas moderados";
    advice = "Pontuação ≥30: possível Transtorno de Luto Prolongado. Recomenda-se avaliação profissional.";
  } else if(total >= 35){
    color = "#D32F2F";
    label = "Vermelho — Sintomas elevados";
    advice = "Pontuação ≥35: risco aumentado e sintomas severos. Procure avaliação clínica urgente; avaliar risco suicida e funcionalidade.";
  }

  async function exportPDF(){
    // build simple HTML
    const html = `
      <html>
        <body style="font-family: Arial, sans-serif; padding:20px;">
          <h1>Inventário de Luto Prolongado — Resultado</h1>
          <p><strong>Pontuação total:</strong> ${total}</p>
          <p><strong>Status:</strong> ${label}</p>
          <p><strong>Itens respondidos:</strong> ${answered}</p>
          <p><strong>Interpretação:</strong> ${advice}</p>
          <hr/>
          <h3>Detalhes (respostas)</h3>
          <pre>${JSON.stringify(data, null, 2)}</pre>
        </body>
      </html>
    `;
    try{
      const { uri } = await Print.printToFileAsync({ html });
      const dest = FileSystem.cacheDirectory + "inventario_resultado.pdf";
      await FileSystem.copyAsync({ from: uri, to: dest });
      await Sharing.shareAsync(dest);
    }catch(e){
      Alert.alert("Erro", "Não foi possível gerar ou partilhar o PDF: " + String(e));
    }
  }

  async function exportCSV(){
    try{
      // build CSV from saved data
      const header = ["Nome","TempoDesdePerda","ItemIndex","Resposta"].join(",");
      const rows = [];
      if(data && Array.isArray(data.answers)){
        data.answers.forEach((ans, i)=>{
          rows.push([data.name || "", data.timeSinceLoss || "", i+1, ans ?? ""].map(v => '"' + String(v).replace(/"/g,'""') + '"').join(","));
        });
      }
      const csv = [header, ...rows].join("
");
      const path = FileSystem.cacheDirectory + "inventario.csv";
      await FileSystem.writeAsStringAsync(path, csv, { encoding: FileSystem.EncodingType.UTF8 });
      await Sharing.shareAsync(path);
    }catch(e){
      Alert.alert("Erro", "Não foi possível exportar CSV: " + String(e));
    }
  }

  function shareText(){
    Alert.alert("Compartilhar", "Você pode exportar em PDF ou CSV para compartilhar o resultado.");
  }

  return (
    <View style={{ flex:1, backgroundColor:"#F6F9FF", padding:16 }}>
      <Text style={{ fontSize:20, fontWeight:"700", color:"#4A90E2", marginBottom:8 }}>Resumo de Pontuação</Text>
      <View style={{ backgroundColor:"#fff", padding:16, borderRadius:12, borderWidth:1, borderColor:"#EEE" }}>
        <Text style={{ fontSize:48, fontWeight:"800", color:color, textAlign:"center" }}>{total}</Text>
        <Text style={{ textAlign:"center", marginTop:8 }}>{label}</Text>
        <Text style={{ marginTop:12, color:"#333" }}>{advice}</Text>
        <Text style={{ marginTop:8, fontSize:12, color:"#666" }}>Itens respondidos: {answered} (interpretação baseada na PG-13/PG-13-R: cortes 30 e 35).</Text>
      </View>

      <TouchableOpacity style={[styles.button,{ backgroundColor:"#7B61FF", marginTop:16 }]} onPress={()=>navigation.navigate("Questionnaire")}>
        <Text style={{ color:"#fff", fontWeight:"700" }}>Refazer Avaliação</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button,{ backgroundColor:"#4A90E2" }]} onPress={exportPDF}>
        <Text style={{ color:"#fff", fontWeight:"700" }}>Exportar PDF</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button,{ backgroundColor:"#009688" }]} onPress={exportCSV}>
        <Text style={{ color:"#fff", fontWeight:"700" }}>Exportar CSV</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button,{ backgroundColor:"#888" }]} onPress={shareText}>
        <Text style={{ color:"#fff", fontWeight:"700" }}>Compartilhar</Text>
      </TouchableOpacity>

      <View style={{ marginTop:18 }}>
        <Text style={{ fontSize:12, color:"#777" }}><Text style={{ fontWeight:"700" }}>Nota:</Text> A PG-13 e a PG-13-R usam escala Likert 1–5. Pontuação igual ou acima de 30 é frequentemente associada a provável TLP; alguns estudos sugerem 35 como ponto de corte mais específico. Este app é ferramenta de triagem e não substitui avaliação clínica.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  button: { padding:14, borderRadius:12, alignItems:"center", justifyContent:"center", marginTop:12 }
});
