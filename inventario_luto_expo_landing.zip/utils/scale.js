export function interpretScore(total){
  if(total >= 35) return { level:"red", label:"Vermelho", message:"Sintomas elevados, procurar avaliação clínica" };
  if(total >= 30) return { level:"yellow", label:"Amarelo", message:"Sintomas moderados, considerar avaliação" };
  return { level:"green", label:"Verde", message:"Sintomas baixos" };
}
